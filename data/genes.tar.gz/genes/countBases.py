#!/usr/bin/env python

import os

curDir=os.getcwd()+'/'
for region in os.listdir(curDir):
	if region not in ['.DS_Store','countBases.py']:
		refBed=curDir+region+'/ref/genes.bed'
		with open(refBed) as inFile:
			baseSet=set()
			for line in inFile:
				line=line.strip().split()
				start,stop=sorted([int(line[1]),int(line[2])])
				for base in range(start,stop+1):
					baseSet.add(base)
			print(region,len(baseSet))
			
